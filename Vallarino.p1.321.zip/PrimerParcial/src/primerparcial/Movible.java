package primerparcial;

public interface Movible {

    void mover();
}
