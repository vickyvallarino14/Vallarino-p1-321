package primerparcial;

public enum TipoConcha {
    ESPIRALADA,
    BIVALVA
}
