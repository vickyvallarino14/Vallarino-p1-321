package primerparcial;

public class Coral extends Especie {

    private int profundidadIdealCrecimiento;

    public Coral(String nombre, String tanqueUbicacion, TipoAgua tipoAgua, int profundidadIdealCrecimiento) {
        super(nombre, tanqueUbicacion, tipoAgua);
        this.profundidadIdealCrecimiento = profundidadIdealCrecimiento;

    }

    @Override
    public void reproducirse() {
        System.out.println("Coral reproduciendose");
    }

    @Override
    public void respirar() {
        System.out.println("Coral respirando");
    }

    @Override
    public String toString() {
        return super.toString() + ", profundidad ideal de crecimiento=" + profundidadIdealCrecimiento + '}';
    }

}
