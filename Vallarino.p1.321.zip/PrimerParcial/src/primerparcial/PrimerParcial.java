package primerparcial;

public class PrimerParcial {

    public static void main(String[] args) {
        Biologo b1 = new Biologo();

        Especie e1 = new Pez("Payaso", "T1", TipoAgua.AGUA_SALADA, 100);
        Especie e2 = new Pez("Salmon", "T1", TipoAgua.AGUA_SALADA, 220);
        //Especie e1 = new Pez("Payaso", "T1", TipoAgua.AGUA_SALADA, 1001); tira excepcion por pasar la longitud
        //Especie e2 = new Pez("Payaso", "T1", TipoAgua.AGUA_SALADA);
        //b1.agregarEspecie(e2); tira exception personalizada

        Especie e3 = new Molusco("Ostra", "T2", TipoAgua.AGUA_DULCE, TipoConcha.BIVALVA);
        Especie e4 = new Molusco("Pulpo", "T3", TipoAgua.AGUA_SALADA, TipoConcha.ESPIRALADA);

        Especie e5 = new Coral("Rosa", "T2", TipoAgua.AGUA_DULCE, 20);
        Especie e6 = new Coral("Celeste", "T3", TipoAgua.AGUA_SALADA, 40);

        b1.agregarEspecie(e1);
        b1.agregarEspecie(e2);
        b1.agregarEspecie(e3);
        b1.agregarEspecie(e4);
        b1.agregarEspecie(e5);
        b1.agregarEspecie(e6);

        System.out.println(b1.mostrarEspecies());

        System.out.println("--------------------");

        b1.moverEspecies();

        System.out.println("--------------------");

        b1.realizarFuncionesBiologicas();

        System.out.println("--------------------");

        System.out.println(b1.filtrarPorTipoAgua(TipoAgua.AGUA_SALADA));
    }

}
