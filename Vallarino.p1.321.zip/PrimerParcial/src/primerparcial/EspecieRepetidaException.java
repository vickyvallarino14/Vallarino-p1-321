package primerparcial;

public class EspecieRepetidaException extends RuntimeException {

    private static final String MESSAGE = "Especie repetida o nula";

    public EspecieRepetidaException() {
        this(MESSAGE);
    }

    public EspecieRepetidaException(String mensaje) {
        super(mensaje);
    }
}
