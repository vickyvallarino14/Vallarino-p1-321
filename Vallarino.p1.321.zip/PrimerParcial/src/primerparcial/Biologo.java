package primerparcial;

import java.util.ArrayList;
import java.util.List;

public class Biologo {

    private List<Especie> especies = new ArrayList<>();

    private void validarEspecie(Especie e) throws EspecieRepetidaException {
        if (e == null || especies.contains(e)) {
            throw new EspecieRepetidaException();
        }
    }

    public void agregarEspecie(Especie e) throws EspecieRepetidaException {
        validarEspecie(e);
        especies.add(e);
    }

    public StringBuilder mostrarEspecies() {
        StringBuilder toReturn = new StringBuilder();
        for (Especie e : especies) {
            toReturn.append(e.toString());
            toReturn.append("\n");
        }
        return toReturn;
    }

    public void moverEspecies() {
        for (Especie e : especies) {
            if (!(e instanceof Movible)) {
                System.out.println("La especie Coral " + e.getNombre() + " no se puede mover por ser sesil");
            } else {
                Movible m = (Movible) e;
                m.mover();
            }
        }
    }

    public void realizarFuncionesBiologicas() {
        for (Especie e : especies) {
            e.respirar();
            e.reproducirse();
            if (seAlimenta(e)) {
                Alimentable a = (Alimentable) e;
                a.alimentar();
            }
        }
    }

    private boolean seAlimenta(Especie e) {
        return e instanceof Alimentable;
    }

    public StringBuilder filtrarPorTipoAgua(TipoAgua tipo) {
        StringBuilder toReturn = new StringBuilder();
        for (Especie e : especies) {
            if (e.getTipoAgua() == tipo) {
                toReturn.append(e.toString());
                toReturn.append("\n");
            }
        }
        return toReturn;
    }
}
