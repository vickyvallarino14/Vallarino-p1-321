package primerparcial;

public class Molusco extends Especie implements Alimentable, Movible {

    private TipoConcha tipoConcha;

    public Molusco(String nombre, String tanqueUbicacion, TipoAgua tipoAgua, TipoConcha tipoConcha) {
        super(nombre, tanqueUbicacion, tipoAgua);
        this.tipoConcha = tipoConcha;
    }

    @Override
    public void reproducirse() {
        System.out.println("Molusco reproduciendose");
    }

    @Override
    public void respirar() {
        System.out.println("Molusco respirando");
    }

    @Override
    public void alimentar() {
        System.out.println("Molusco alimentandose");
    }

    @Override
    public String toString() {
        return super.toString() + ", tipo concha: " + tipoConcha + '}';
    }

    @Override
    public void mover() {
        System.out.println("Molusco moviendose");
    }

}
