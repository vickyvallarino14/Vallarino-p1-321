package primerparcial;

import java.util.Objects;

public abstract class Especie {

    private String nombre;
    private String tanqueUbicacion;
    private TipoAgua tipoAgua;

    public Especie(String nombre, String tanqueUbicacion, TipoAgua tipoAgua) {
        this.nombre = nombre;
        this.tanqueUbicacion = tanqueUbicacion;
        this.tipoAgua = tipoAgua;
    }

    public abstract void reproducirse();

    public abstract void respirar();

    @Override
    public int hashCode() {
        return Objects.hash(nombre, tanqueUbicacion);
    }

    @Override
    public boolean equals(Object obj) {
        if ((obj == null) || !(obj instanceof Especie e)) {
            return false;
        }
        return nombre.equals(e.nombre) && tanqueUbicacion.equals(e.tanqueUbicacion);
    }

    @Override
    public String toString() {
        return "Especie{" + "nombre: " + nombre + ", tanque ubicacion: " + tanqueUbicacion + ", tipo agua: " + tipoAgua;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoAgua getTipoAgua() {
        return tipoAgua;
    }

}
