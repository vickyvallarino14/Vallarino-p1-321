package primerparcial;

public interface Alimentable {

    void alimentar();
}
