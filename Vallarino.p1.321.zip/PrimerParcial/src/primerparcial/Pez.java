package primerparcial;

public class Pez extends Especie implements Alimentable, Movible {

    private int longitud;
    private static final int LONGITUD_MAXIMA = 1000;

    @Override
    public void reproducirse() {
        System.out.println("Pez reproduciendose");
    }

    @Override
    public void respirar() {
        System.out.println("Pez respirando");
    }

    public Pez(String nombre, String tanqueUbicacion, TipoAgua tipoAgua, int longitud) {

        super(nombre, tanqueUbicacion, tipoAgua);
        validarLongitud(longitud);
        this.longitud = longitud;
    }

    @Override
    public void alimentar() {
        System.out.println("Pez alimentandose");
    }

    @Override
    public String toString() {
        return super.toString() + ", longitud: " + longitud + '}';
    }

    @Override
    public void mover() {
        System.out.println("Pez moviendose");
    }

    private void validarLongitud(int longitud) {
        if (longitud > LONGITUD_MAXIMA) {
            throw new IllegalArgumentException("Logintud maxima alcanzada");
        }
    }

}
